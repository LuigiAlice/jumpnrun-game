JUMP & RUN ABENTEUER
====================

So starten Sie das Spiel:

Windows:
  Doppelklicken Sie start.bat oder öffnen Sie eine CMD und geben Sie ein:
  python -m http.server 8000

Mac/Linux:
  Öffnen Sie ein Terminal und geben Sie ein:
  python3 -m http.server 8000

Dann öffnen Sie Ihren Browser und gehen Sie zu:
  http://localhost:8000

Steuerung:
- Pfeil Links/Rechts: Bewegen
- Pfeil nach oben: Springen
- X: Schießen (nur Fire Mario)
- R: Level neustarten
- N: Nächstes Level
- ESC: Zurück zum Menü

Viel Spaß beim Spielen!
