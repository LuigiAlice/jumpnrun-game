@echo off
echo Starting Jump & Run Game...
python -m http.server 8000
echo Open http://localhost:8000 in your browser
